"use client"

import { useState } from "react"
import { UserSwitcher } from "./components/UserSwitcher"
import { DocumentUpload } from "./components/DocumentUpload"
import { DocumentList } from "./components/DocumentList"
import { PDFViewer } from "./components/PDFViewer"
import { Button } from "./components/ui/button"
import type { User } from "./types"

export default function App() {
  const [currentUser, setCurrentUser] = useState<User>({
    id: "A1",
    name: "Admin",
    role: "admin",
  })
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null)
  const [documents, setDocuments] = useState<any[]>([])

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-foreground">PDF Annotator</h1>
            <p className="text-sm text-muted-foreground">Collaborate on documents with role-based access</p>
          </div>
          <UserSwitcher currentUser={currentUser} onUserChange={setCurrentUser} />
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {selectedDoc ? (
          <div className="space-y-4">
            <Button variant="outline" onClick={() => setSelectedDoc(null)} className="mb-4">
              ← Back to Documents
            </Button>
            <PDFViewer documentId={selectedDoc} currentUser={currentUser} />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-1">
              {currentUser.role === "admin" && (
                <DocumentUpload
                  onUploadSuccess={(doc) => {
                    setDocuments([...documents, doc])
                  }}
                />
              )}
            </div>
            <div className="lg:col-span-3">
              <DocumentList documents={documents} currentUser={currentUser} onSelectDoc={setSelectedDoc} />
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
