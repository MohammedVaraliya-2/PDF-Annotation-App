"use client"

import { useState, useEffect } from "react"
import type { User, Annotation } from "../types"
import { Card, CardContent } from "./ui/card"
import { Button } from "./ui/button"
import { Textarea } from "./ui/textarea"

interface PDFViewerProps {
  documentId: string
  currentUser: User
}

export function PDFViewer({ documentId, currentUser }: PDFViewerProps) {
  const [annotations, setAnnotations] = useState<Annotation[]>([])
  const [loading, setLoading] = useState(true)
  const [newAnnotation, setNewAnnotation] = useState("")
  const [visibleTo, setVisibleTo] = useState<string[]>(["A1", "D1", "D2", "R1"])

  useEffect(() => {
    fetchAnnotations()
  }, [documentId, currentUser.id])

  const fetchAnnotations = async () => {
    try {
      const response = await fetch(`http://localhost:5000/api/annotations/${documentId}`, {
        headers: {
          "x-user-id": currentUser.id,
          "x-user-role": currentUser.role,
        },
      })
      const data = await response.json()
      setAnnotations(data.annotations || [])
    } catch (err) {
      console.error("Failed to fetch annotations:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleAddAnnotation = async () => {
    if (!newAnnotation.trim()) return

    try {
      const response = await fetch("http://localhost:5000/api/annotations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": currentUser.id,
          "x-user-role": currentUser.role,
        },
        body: JSON.stringify({
          documentId,
          type: "comment",
          content: newAnnotation,
          position: { page: 1, x: 0, y: 0 },
          visibleTo,
        }),
      })

      if (response.ok) {
        setNewAnnotation("")
        await fetchAnnotations()
      }
    } catch (err) {
      console.error("Failed to add annotation:", err)
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card>
          <CardContent className="pt-6">
            <div className="bg-muted rounded-lg p-8 text-center">
              <p className="text-muted-foreground">PDF Viewer Component (Integrate react-pdf here)</p>
              <p className="text-sm text-muted-foreground mt-2">Document: {documentId}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold text-foreground mb-4">Annotations</h3>

            {currentUser.role !== "readonly" && (
              <div className="space-y-3 mb-6 pb-6 border-b border-border">
                <Textarea
                  placeholder="Add a comment..."
                  value={newAnnotation}
                  onChange={(e) => setNewAnnotation(e.target.value)}
                  className="text-sm"
                />
                <Button onClick={handleAddAnnotation} size="sm" className="w-full">
                  Add Comment
                </Button>
              </div>
            )}

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {loading ? (
                <p className="text-sm text-muted-foreground">Loading annotations...</p>
              ) : annotations.length === 0 ? (
                <p className="text-sm text-muted-foreground">No annotations yet</p>
              ) : (
                annotations.map((ann) => (
                  <div key={ann._id} className="p-3 bg-muted rounded-lg border border-border">
                    <p className="text-xs font-medium text-foreground mb-1">{ann.createdBy}</p>
                    <p className="text-sm text-foreground">{ann.content}</p>
                    <p className="text-xs text-muted-foreground mt-2">{new Date(ann.createdAt).toLocaleDateString()}</p>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
