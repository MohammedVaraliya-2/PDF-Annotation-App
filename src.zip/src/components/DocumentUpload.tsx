"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"

interface DocumentUploadProps {
  onUploadSuccess: (doc: any) => void
}

export function DocumentUpload({ onUploadSuccess }: DocumentUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState("")

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files
    if (!files) return

    setUploading(true)
    setError("")

    try {
      const formData = new FormData()
      for (let i = 0; i < files.length; i++) {
        formData.append("files", files[i])
      }

      const response = await fetch("http://localhost:5000/api/documents/upload", {
        method: "POST",
        body: formData,
        headers: {
          "x-user-id": "A1",
          "x-user-role": "admin",
        },
      })

      if (!response.ok) throw new Error("Upload failed")

      const data = await response.json()
      data.documents.forEach(onUploadSuccess)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed")
    } finally {
      setUploading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Documents</CardTitle>
        <CardDescription>Admin only: Upload single or multiple PDFs</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors">
            <input
              type="file"
              multiple
              accept=".pdf"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer block">
              <p className="text-sm font-medium text-foreground">Click to upload PDFs</p>
              <p className="text-xs text-muted-foreground mt-1">or drag and drop</p>
            </label>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          {uploading && <p className="text-sm text-muted-foreground">Uploading...</p>}
        </div>
      </CardContent>
    </Card>
  )
}
